Minetest 0.4 mod: bones
=======================

License of source code:
-----------------------
Copyright (C) 2012 PilzAdam

WTFPL

License of media (textures and sounds)
--------------------------------------
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/

Authors of media files
----------------------
Bad_Command_
